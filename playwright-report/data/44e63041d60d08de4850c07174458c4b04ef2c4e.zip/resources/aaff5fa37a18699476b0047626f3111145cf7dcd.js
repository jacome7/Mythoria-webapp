(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_7f9435ca._.js",
  "static/chunks/node_modules_e7596127._.js"
],
    source: "dynamic"
});
