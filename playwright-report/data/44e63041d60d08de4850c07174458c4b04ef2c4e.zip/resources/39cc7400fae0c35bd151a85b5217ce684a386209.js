(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/GoogleAnalytics.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GoogleAnalytics,
    "trackEvent",
    ()=>trackEvent,
    "trackPageView",
    ()=>trackPageView
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/script.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function GoogleAnalytics(param) {
    let { measurementId, googleAdsId, googleTagId } = param;
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GoogleAnalytics.useEffect": ()=>{
            // Initialize dataLayer if it doesn't exist
            window.dataLayer = window.dataLayer || []; // Define gtag function
            // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/no-unused-vars
            function gtag() {
                for(var _len = arguments.length, _args = new Array(_len), _key = 0; _key < _len; _key++){
                    _args[_key] = arguments[_key];
                }
                // eslint-disable-next-line prefer-rest-params
                window.dataLayer.push(arguments);
            }
            // Make gtag available globally
            window.gtag = gtag;
            // Initialize Google Analytics
            gtag("js", new Date());
            // Configure Google Analytics
            gtag("config", measurementId);
            // Configure Google Ads if provided
            if (googleAdsId) {
                gtag("config", googleAdsId);
            }
            // Configure Google Tag if provided
            if (googleTagId) {
                gtag("config", googleTagId);
            }
        }
    }["GoogleAnalytics.useEffect"], [
        measurementId,
        googleAdsId,
        googleTagId
    ]);
    if (!measurementId) {
        return null;
    }
    // Use the primary measurement ID for the script source
    const scriptId = googleTagId || measurementId;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$script$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            src: "https://www.googletagmanager.com/gtag/js?id=".concat(scriptId),
            strategy: "afterInteractive"
        }, void 0, false, {
            fileName: "[project]/src/components/GoogleAnalytics.tsx",
            lineNumber: 64,
            columnNumber: 7
        }, this)
    }, void 0, false);
}
_s(GoogleAnalytics, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = GoogleAnalytics;
const trackEvent = (eventName, parameters)=>{
    if ("object" !== "undefined" && window.gtag) {
        window.gtag("event", eventName, parameters);
    }
};
const trackPageView = (url)=>{
    if ("object" !== "undefined" && window.gtag) {
        window.gtag("config", ("TURBOPACK compile-time value", "G-86D0QFW197"), {
            page_location: url
        });
    }
};
var _c;
__turbopack_context__.k.register(_c, "GoogleAnalytics");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/useGoogleAnalytics.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useGoogleAnalytics",
    ()=>useGoogleAnalytics
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function useGoogleAnalytics() {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useGoogleAnalytics.useEffect": ()=>{
            if ("object" !== 'undefined' && window.gtag) {
                const path = pathname || window.location.pathname;
                const sp = searchParams ? searchParams.toString() : '';
                const url = path + (sp ? "?".concat(sp) : '');
                window.gtag('config', ("TURBOPACK compile-time value", "G-86D0QFW197") || 'G-86D0QFW197', {
                    page_location: window.location.origin + url,
                    page_title: document.title
                });
            }
        }
    }["useGoogleAnalytics.useEffect"], [
        pathname,
        searchParams
    ]);
}
_s(useGoogleAnalytics, "h6p6PpCFmP4Mu5bIMduBzSZThBE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/googleAdsConversions.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "trackConversion",
    ()=>trackConversion,
    "trackMythoriaConversions",
    ()=>trackMythoriaConversions,
    "trackMythoriaConversionsEnhanced",
    ()=>trackMythoriaConversionsEnhanced
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use client';
function trackConversion(conversionLabel) {
    let params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    if ("object" === 'undefined' || !window.gtag) {
        console.log("Conversion event (not sent): ".concat(conversionLabel), params);
        return;
    }
    try {
        const eventParams = {
            send_to: conversionLabel,
            ...params
        };
        window.gtag('event', 'conversion', eventParams);
        if ("TURBOPACK compile-time truthy", 1) {
            console.log("Conversion event sent: ".concat(conversionLabel), eventParams);
        }
    } catch (error) {
        console.error('Error tracking conversion:', error);
    }
}
const trackMythoriaConversions = {
    /**
   * Track user sign-up conversion
   */ signUp: function() {
        let params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        const googleAdsId = ("TURBOPACK compile-time value", "AW-17204783135");
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        // Google Ads conversion label: bti2COKh8_kaEJ_Q8ItA
        trackConversion("".concat(googleAdsId, "/bti2COKh8_kaEJ_Q8ItA"), params);
    },
    /**
   * Track story creation conversion
   */ storyCreated: function() {
        let params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        const googleAdsId = ("TURBOPACK compile-time value", "AW-17204783135");
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        // Google Ads conversion label: N0-wCOWh8_kaEJ_Q8ItA
        trackConversion("".concat(googleAdsId, "/N0-wCOWh8_kaEJ_Q8ItA"), {
            value: 1.0,
            currency: 'EUR',
            ...params
        });
    },
    /**
   * Track credit purchase conversion
   */ creditPurchase: function() {
        let params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        const googleAdsId = ("TURBOPACK compile-time value", "AW-17204783135");
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        // Google Ads conversion label: BxUzCOih8_kaEJ_Q8ItA
        trackConversion("".concat(googleAdsId, "/BxUzCOih8_kaEJ_Q8ItA"), {
            currency: 'EUR',
            ...params
        });
    }
};
const trackMythoriaConversionsEnhanced = {
    signUp: (userId)=>{
        trackMythoriaConversions.signUp({
            transaction_id: userId || "signup_".concat(Date.now())
        });
    },
    storyCreated: (storyId, userId)=>{
        trackMythoriaConversions.storyCreated({
            transaction_id: storyId || "story_".concat(userId, "_").concat(Date.now())
        });
    },
    creditPurchase: function(amount) {
        let currency = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 'EUR', transactionId = arguments.length > 2 ? arguments[2] : void 0;
        trackMythoriaConversions.creditPurchase({
            value: amount,
            currency,
            transaction_id: transactionId || "purchase_".concat(Date.now())
        });
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/analytics.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "setUserId",
    ()=>setUserId,
    "setUserProperties",
    ()=>setUserProperties,
    "trackAuth",
    ()=>trackAuth,
    "trackCommerce",
    ()=>trackCommerce,
    "trackContact",
    ()=>trackContact,
    "trackEvent",
    ()=>trackEvent,
    "trackStoryCreation",
    ()=>trackStoryCreation,
    "trackStoryManagement",
    ()=>trackStoryManagement
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$googleAdsConversions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/googleAdsConversions.ts [app-client] (ecmascript)");
'use client';
;
function trackEvent(eventName) {
    let parameters = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    if ("object" === 'undefined' || !window.gtag) {
        // If we're on the server side or gtag is not available, log the event for debugging
        console.log("Analytics event (not sent): ".concat(eventName), parameters);
        return;
    }
    try {
        // Add timestamp and common parameters
        const eventParams = {
            ...parameters,
            timestamp: new Date().toISOString(),
            page_location: window.location.href,
            page_title: document.title
        };
        // Send the event to Google Analytics
        window.gtag('event', eventName, eventParams);
        // Log for debugging in development
        if ("TURBOPACK compile-time truthy", 1) {
            console.log("Analytics event sent: ".concat(eventName), eventParams);
        }
    } catch (error) {
        console.error('Error tracking analytics event:', error);
    }
}
const trackAuth = {
    signUp: function() {
        let params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        trackEvent('sign_up', params);
        // Track Google Ads conversion
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$googleAdsConversions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackMythoriaConversionsEnhanced"].signUp(params.user_id);
    },
    login: function() {
        let params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        return trackEvent('login', params);
    },
    logout: function() {
        let params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        return trackEvent('logout', params);
    }
};
const trackCommerce = {
    creditPurchase: function() {
        let params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        trackEvent('credit_purchase', params);
        // Track Google Ads conversion
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$googleAdsConversions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackMythoriaConversionsEnhanced"].creditPurchase(params.purchase_amount || 0, 'EUR', params.transaction_id);
    }
};
const trackStoryCreation = {
    started: function() {
        let params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        return trackEvent('story_creation_started', params);
    },
    step1Completed: function() {
        let params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        return trackEvent('story_step1_completed', params);
    },
    step2Completed: function() {
        let params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        return trackEvent('story_step2_completed', params);
    },
    step3Completed: function() {
        let params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        return trackEvent('story_step3_completed', params);
    },
    step4Completed: function() {
        let params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        return trackEvent('story_step4_completed', params);
    },
    step5Completed: function() {
        let params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        return trackEvent('story_step5_completed', params);
    },
    characterAdded: function() {
        let params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        return trackEvent('character_added', params);
    },
    characterCustomized: function() {
        let params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        return trackEvent('character_customized', params);
    },
    generationRequested: function() {
        let params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        trackEvent('story_generation_requested', params);
        // Track Google Ads conversion for story creation
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$googleAdsConversions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackMythoriaConversionsEnhanced"].storyCreated(params.story_id, params.user_id);
    }
};
const trackStoryManagement = {
    viewed: function() {
        let params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        return trackEvent('story_viewed', params);
    },
    edited: function() {
        let params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        return trackEvent('story_edited', params);
    },
    shared: function() {
        let params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        return trackEvent('story_shared', params);
    },
    deleted: function() {
        let params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        return trackEvent('story_deleted', params);
    },
    listen: function() {
        let params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        return trackEvent('story_listen', params);
    }
};
const trackContact = {
    request: function() {
        let params = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        return trackEvent('contact_request', params);
    }
};
function setUserProperties(properties) {
    if ("object" === 'undefined' || !window.gtag) {
        return;
    }
    try {
        window.gtag('config', ("TURBOPACK compile-time value", "G-86D0QFW197") || 'G-86D0QFW197', {
            user_properties: properties
        });
    } catch (error) {
        console.error('Error setting user properties:', error);
    }
}
function setUserId(userId) {
    if ("object" === 'undefined' || !window.gtag) {
        return;
    }
    try {
        window.gtag('config', ("TURBOPACK compile-time value", "G-86D0QFW197") || 'G-86D0QFW197', {
            user_id: userId
        });
    } catch (error) {
        console.error('Error setting user ID:', error);
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/hooks/useAuthTracking.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useAuthTracking",
    ()=>useAuthTracking
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$clerk$2f$shared$2f$dist$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@clerk/shared/dist/react/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$analytics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/analytics.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function useAuthTracking() {
    _s();
    const { isSignedIn, user, isLoaded } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$clerk$2f$shared$2f$dist$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUser"])();
    const prevSignedInRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const hasTrackedSignupRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useAuthTracking.useEffect": ()=>{
            if (!isLoaded) return;
            const prevSignedIn = prevSignedInRef.current;
            const currentSignedIn = isSignedIn; // Track sign up (user went from not signed in to signed in, and it's a new user)
            if (!prevSignedIn && currentSignedIn && user && user.createdAt) {
                var _user_primaryEmailAddress;
                const createdAt = new Date(user.createdAt);
                const now = new Date();
                const timeDiff = now.getTime() - createdAt.getTime();
                const isNewUser = timeDiff < 5 * 60 * 1000; // Within 5 minutes is considered "new"
                if (isNewUser && !hasTrackedSignupRef.current) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$analytics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackAuth"].signUp({
                        user_id: user.id,
                        sign_up_method: user.primaryEmailAddress ? 'email' : 'social'
                    });
                    hasTrackedSignupRef.current = true;
                } else if (!hasTrackedSignupRef.current) {
                    // Existing user logging in
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$analytics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackAuth"].login({
                        user_id: user.id,
                        login_method: user.primaryEmailAddress ? 'email' : 'social'
                    });
                }
                // Set user properties for analytics
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$analytics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setUserId"])(user.id);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$analytics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setUserProperties"])({
                    signup_date: user.createdAt.toISOString(),
                    email_verified: !!((_user_primaryEmailAddress = user.primaryEmailAddress) === null || _user_primaryEmailAddress === void 0 ? void 0 : _user_primaryEmailAddress.verification.status),
                    profile_complete: !!(user.firstName && user.lastName)
                });
            }
            // Track logout (user went from signed in to not signed in)
            if (prevSignedIn && !currentSignedIn) {
                __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$analytics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trackAuth"].logout();
            }
            // Update the ref for next comparison
            prevSignedInRef.current = currentSignedIn;
        }
    }["useAuthTracking.useEffect"], [
        isLoaded,
        isSignedIn,
        user
    ]);
    return {
        isSignedIn,
        user,
        isLoaded
    };
}
_s(useAuthTracking, "tkIyfezjelZfcVzxHAT9WAgLDq0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$clerk$2f$shared$2f$dist$2f$react$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUser"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/AnalyticsProvider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AnalyticsProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$useGoogleAnalytics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/useGoogleAnalytics.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useAuthTracking$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useAuthTracking.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function AnalyticsTracker() {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$useGoogleAnalytics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGoogleAnalytics"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useAuthTracking$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthTracking"])();
    return null;
}
_s(AnalyticsTracker, "CdDPxLhWFslysDjysOvhuTYUQZw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$useGoogleAnalytics$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGoogleAnalytics"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useAuthTracking$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuthTracking"]
    ];
});
_c = AnalyticsTracker;
function AnalyticsProvider(param) {
    let { children } = param;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
                fallback: null,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AnalyticsTracker, {}, void 0, false, {
                    fileName: "[project]/src/components/AnalyticsProvider.tsx",
                    lineNumber: 21,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/AnalyticsProvider.tsx",
                lineNumber: 20,
                columnNumber: 7
            }, this),
            children
        ]
    }, void 0, true);
}
_c1 = AnalyticsProvider;
var _c, _c1;
__turbopack_context__.k.register(_c, "AnalyticsTracker");
__turbopack_context__.k.register(_c1, "AnalyticsProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_44a9ab27._.js.map