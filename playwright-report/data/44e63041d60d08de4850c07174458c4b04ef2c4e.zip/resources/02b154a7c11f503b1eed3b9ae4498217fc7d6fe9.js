(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/utils/date.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatDate",
    ()=>formatDate
]);
function formatDate(date) {
    let options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    const { locale = "en-US", ...formatOptions } = options;
    const d = typeof date === "string" || typeof date === "number" ? new Date(date) : date;
    if (isNaN(d.getTime())) return "-";
    return new Intl.DateTimeFormat(locale, formatOptions).format(d);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/PublicStoryRating.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PublicStoryRating
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$date$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/date.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function PublicStoryRating(param) {
    let { storyId, onRatingSubmitted } = param;
    _s();
    const tCommonStoryRating = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])("StoryRating");
    const [userRating, setUserRating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [hoveredRating, setHoveredRating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [feedback, setFeedback] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [includeNameInFeedback, setIncludeNameInFeedback] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showFeedbackForm, setShowFeedbackForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isSubmitting, setIsSubmitting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [submitted, setSubmitted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [ratingData, setRatingData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    // Fetch rating data on component mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PublicStoryRating.useEffect": ()=>{
            const fetchRatingData = {
                "PublicStoryRating.useEffect.fetchRatingData": async ()=>{
                    try {
                        const response = await fetch("/api/stories/".concat(storyId, "/ratings"));
                        if (response.ok) {
                            const data = await response.json();
                            setRatingData(data);
                            if (data.userRating) {
                                setUserRating(parseInt(data.userRating.rating));
                                setFeedback(data.userRating.feedback || "");
                            }
                        }
                    } catch (error) {
                        console.error("Error fetching rating data:", error);
                    } finally{
                        setLoading(false);
                    }
                }
            }["PublicStoryRating.useEffect.fetchRatingData"];
            fetchRatingData();
        }
    }["PublicStoryRating.useEffect"], [
        storyId
    ]);
    const handleStarClick = (starRating)=>{
        setUserRating(starRating);
        setError(null);
        setHoveredRating(0); // Reset hover state after click
        // Show feedback form for ratings 1-3
        if (starRating <= 3) {
            setShowFeedbackForm(true);
        } else {
            // For ratings 4-5, submit immediately
            handleSubmitRating(starRating);
        }
    };
    const handleSubmitRating = async function() {
        let finalRating = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : userRating, finalFeedback = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : feedback;
        setIsSubmitting(true);
        setError(null);
        try {
            const response = await fetch("/api/stories/".concat(storyId, "/ratings"), {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    rating: finalRating.toString(),
                    feedback: finalFeedback || null,
                    includeNameInFeedback
                })
            });
            if (!response.ok) {
                const errorData = await response.json();
                if (response.status === 503) {
                    throw new Error(tCommonStoryRating("errors.serviceUnavailable"));
                }
                throw new Error(errorData.error || tCommonStoryRating("errors.submitFailed"));
            }
            const result = await response.json();
            // Update rating data with new user rating
            if (ratingData) {
                setRatingData({
                    ...ratingData,
                    userRating: {
                        ratingId: result.rating.ratingId,
                        rating: result.rating.rating,
                        feedback: result.rating.feedback,
                        createdAt: result.rating.createdAt
                    }
                });
            }
            setSubmitted(true);
            onRatingSubmitted === null || onRatingSubmitted === void 0 ? void 0 : onRatingSubmitted(finalRating);
            // Reset form state after successful submission
            setShowFeedbackForm(false);
            // Refresh rating data to get updated average
            setTimeout(async ()=>{
                try {
                    const refreshResponse = await fetch("/api/stories/".concat(storyId, "/ratings"));
                    if (refreshResponse.ok) {
                        const refreshedData = await refreshResponse.json();
                        setRatingData(refreshedData);
                    }
                } catch (error) {
                    console.error("Error refreshing rating data:", error);
                }
            }, 500);
        } catch (err) {
            setError(err instanceof Error ? err.message : tCommonStoryRating("errors.generic"));
        } finally{
            setIsSubmitting(false);
        }
    };
    const handleFeedbackSubmit = (e)=>{
        e.preventDefault();
        handleSubmitRating(userRating, feedback);
    };
    const renderUnifiedStars = ()=>{
        return [
            1,
            2,
            3,
            4,
            5
        ].map((star)=>{
            // Determine what rating to show:
            // 1. If hovering, show hovered rating
            // 2. Otherwise show average rating
            const displayRating = hoveredRating || (ratingData === null || ratingData === void 0 ? void 0 : ratingData.averageRating) || 0;
            const isFilled = star <= displayRating;
            const isHalfFilled = !isFilled && star - 0.5 <= displayRating;
            // Determine colors based on state
            let colorClass = "text-base-300"; // default empty
            if (hoveredRating && star <= hoveredRating) {
                colorClass = "text-warning brightness-110"; // brighter when hovering
            } else if (isFilled || isHalfFilled) {
                colorClass = "text-warning"; // normal filled
            }
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                className: "btn btn-ghost p-1 text-3xl transition-all duration-200 hover:scale-110 ".concat(colorClass, " cursor-pointer"),
                onClick: ()=>handleStarClick(star),
                onMouseEnter: ()=>setHoveredRating(star),
                onMouseLeave: ()=>setHoveredRating(0),
                disabled: isSubmitting,
                title: tCommonStoryRating("starTooltip", {
                    count: star,
                    plural: star !== 1 ? "s" : ""
                }),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiStar"], {
                    className: hoveredRating && star <= hoveredRating || isFilled || isHalfFilled ? "fill-current" : ""
                }, void 0, false, {
                    fileName: "[project]/src/components/PublicStoryRating.tsx",
                    lineNumber: 198,
                    columnNumber: 11
                }, this)
            }, star, false, {
                fileName: "[project]/src/components/PublicStoryRating.tsx",
                lineNumber: 185,
                columnNumber: 9
            }, this);
        });
    };
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "card bg-base-100 shadow-xl border-2 border-base-300",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "card-body text-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "loading loading-spinner loading-lg"
                }, void 0, false, {
                    fileName: "[project]/src/components/PublicStoryRating.tsx",
                    lineNumber: 216,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/PublicStoryRating.tsx",
                lineNumber: 215,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/PublicStoryRating.tsx",
            lineNumber: 214,
            columnNumber: 7
        }, this);
    }
    if (submitted) {
        // After submission, reset the submitted state and show the normal rating interface
        setTimeout(()=>{
            setSubmitted(false);
        }, 100);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "card bg-base-100 shadow-xl border-2 border-base-300",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "card-body py-2",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "card-title justify-center mb-2",
                        children: tCommonStoryRating("title") || "Rate this Story"
                    }, void 0, false, {
                        fileName: "[project]/src/components/PublicStoryRating.tsx",
                        lineNumber: 231,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-center items-center gap-1 mb-1",
                                children: renderUnifiedStars()
                            }, void 0, false, {
                                fileName: "[project]/src/components/PublicStoryRating.tsx",
                                lineNumber: 238,
                                columnNumber: 13
                            }, this),
                            ratingData && ratingData.totalRatings > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-lg font-semibold mb-1",
                                        children: [
                                            ratingData.averageRating.toFixed(1),
                                            "/5"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/PublicStoryRating.tsx",
                                        lineNumber: 245,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm text-base-content/70",
                                        children: tCommonStoryRating("basedOnRatings", {
                                            count: ratingData.totalRatings,
                                            plural: ratingData.totalRatings !== 1 ? "s" : ""
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/PublicStoryRating.tsx",
                                        lineNumber: 248,
                                        columnNumber: 17
                                    }, this),
                                    hoveredRating > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm text-info mt-2",
                                        children: tCommonStoryRating("clickToRate", {
                                            count: hoveredRating,
                                            plural: hoveredRating !== 1 ? "s" : ""
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/PublicStoryRating.tsx",
                                        lineNumber: 255,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/PublicStoryRating.tsx",
                                lineNumber: 244,
                                columnNumber: 15
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-base-content/70 mb-2",
                                        children: tCommonStoryRating("noRatingsYet")
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/PublicStoryRating.tsx",
                                        lineNumber: 265,
                                        columnNumber: 17
                                    }, this),
                                    hoveredRating > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm text-info",
                                        children: tCommonStoryRating("clickToRate", {
                                            count: hoveredRating,
                                            plural: hoveredRating !== 1 ? "s" : ""
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/PublicStoryRating.tsx",
                                        lineNumber: 269,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/PublicStoryRating.tsx",
                                lineNumber: 264,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/PublicStoryRating.tsx",
                        lineNumber: 236,
                        columnNumber: 11
                    }, this),
                    (ratingData === null || ratingData === void 0 ? void 0 : ratingData.userRating) && !submitted && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-3 p-2 bg-info/10 rounded-lg border border-info/20",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm text-info",
                                children: [
                                    tCommonStoryRating("yourCurrentRating"),
                                    ":",
                                    " ",
                                    ratingData.userRating.rating,
                                    " ⭐",
                                    ratingData.userRating.createdAt && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "ml-2 text-xs",
                                        children: [
                                            "(",
                                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$date$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatDate"])(ratingData.userRating.createdAt),
                                            ")"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/PublicStoryRating.tsx",
                                        lineNumber: 287,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/PublicStoryRating.tsx",
                                lineNumber: 283,
                                columnNumber: 15
                            }, this),
                            ratingData.userRating.feedback && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-base-content/70 mt-1",
                                children: [
                                    "“",
                                    ratingData.userRating.feedback,
                                    "”"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/PublicStoryRating.tsx",
                                lineNumber: 293,
                                columnNumber: 17
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/PublicStoryRating.tsx",
                        lineNumber: 282,
                        columnNumber: 13
                    }, this),
                    showFeedbackForm && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                        onSubmit: handleFeedbackSubmit,
                        className: "mt-4 space-y-3 border-tCommonStoryRating pt-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-center mb-3",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-base-content/70",
                                    children: [
                                        tCommonStoryRating("youSelected"),
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold",
                                            children: [
                                                userRating,
                                                " star",
                                                userRating !== 1 ? "s" : ""
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/PublicStoryRating.tsx",
                                            lineNumber: 309,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/PublicStoryRating.tsx",
                                    lineNumber: 307,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/PublicStoryRating.tsx",
                                lineNumber: 306,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-left",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "feedback",
                                        className: "label",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "label-text",
                                            children: tCommonStoryRating("feedback.title")
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/PublicStoryRating.tsx",
                                            lineNumber: 317,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/PublicStoryRating.tsx",
                                        lineNumber: 316,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                        id: "feedback",
                                        className: "textarea textarea-bordered w-full h-20 resize-none",
                                        placeholder: tCommonStoryRating("feedback.placeholder"),
                                        value: feedback,
                                        onChange: (e)=>setFeedback(e.target.value),
                                        disabled: isSubmitting
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/PublicStoryRating.tsx",
                                        lineNumber: 321,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/PublicStoryRating.tsx",
                                lineNumber: 315,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "form-control",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "label cursor-pointer justify-start gap-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "checkbox",
                                            className: "checkbox checkbox-primary",
                                            checked: includeNameInFeedback,
                                            onChange: (e)=>setIncludeNameInFeedback(e.target.checked),
                                            disabled: isSubmitting
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/PublicStoryRating.tsx",
                                            lineNumber: 333,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "label-text",
                                            children: tCommonStoryRating("feedback.includeNameLabel")
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/PublicStoryRating.tsx",
                                            lineNumber: 340,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/PublicStoryRating.tsx",
                                    lineNumber: 332,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/PublicStoryRating.tsx",
                                lineNumber: 331,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-2 justify-end",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        className: "btn btn-ghost",
                                        onClick: ()=>setShowFeedbackForm(false),
                                        disabled: isSubmitting,
                                        children: tCommonStoryRating("buttons.cancel")
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/PublicStoryRating.tsx",
                                        lineNumber: 347,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "submit",
                                        className: "btn btn-primary",
                                        disabled: isSubmitting,
                                        children: isSubmitting ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "loading loading-spinner loading-sm"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/PublicStoryRating.tsx",
                                                    lineNumber: 362,
                                                    columnNumber: 23
                                                }, this),
                                                tCommonStoryRating("buttons.submitting")
                                            ]
                                        }, void 0, true) : (ratingData === null || ratingData === void 0 ? void 0 : ratingData.userRating) ? tCommonStoryRating("buttons.updateRating") : tCommonStoryRating("buttons.submitRating")
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/PublicStoryRating.tsx",
                                        lineNumber: 355,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/PublicStoryRating.tsx",
                                lineNumber: 346,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/PublicStoryRating.tsx",
                        lineNumber: 302,
                        columnNumber: 13
                    }, this),
                    error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "alert alert-error mt-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: error
                        }, void 0, false, {
                            fileName: "[project]/src/components/PublicStoryRating.tsx",
                            lineNumber: 378,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/PublicStoryRating.tsx",
                        lineNumber: 377,
                        columnNumber: 13
                    }, this),
                    isSubmitting && !showFeedbackForm && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-center gap-2 mt-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "loading loading-spinner loading-sm"
                            }, void 0, false, {
                                fileName: "[project]/src/components/PublicStoryRating.tsx",
                                lineNumber: 385,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: tCommonStoryRating("submittingMessage")
                            }, void 0, false, {
                                fileName: "[project]/src/components/PublicStoryRating.tsx",
                                lineNumber: 386,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/PublicStoryRating.tsx",
                        lineNumber: 384,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/PublicStoryRating.tsx",
                lineNumber: 230,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/PublicStoryRating.tsx",
            lineNumber: 229,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/PublicStoryRating.tsx",
        lineNumber: 228,
        columnNumber: 5
    }, this);
}
_s(PublicStoryRating, "TWmZIRSsn6KimnL2WRy/JkWmGHE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"]
    ];
});
_c = PublicStoryRating;
var _c;
__turbopack_context__.k.register(_c, "PublicStoryRating");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/ReadingToolbar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ReadingToolbar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const DEFAULT_SETTINGS = {
    fontSize: 100,
    lineHeight: 100,
    margins: 100
};
function ReadingToolbar(param) {
    let { onSettingsChange, chapters = [], currentChapter = 0, onChapterChange } = param;
    _s();
    const tReadingToolbar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])('ReadingToolbar');
    const [settings, setSettings] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(DEFAULT_SETTINGS);
    const [isExpanded, setIsExpanded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Load settings from localStorage on mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ReadingToolbar.useEffect": ()=>{
            const savedSettings = localStorage.getItem('mythoria-reading-settings');
            if (savedSettings) {
                try {
                    const parsed = JSON.parse(savedSettings);
                    setSettings({
                        ...DEFAULT_SETTINGS,
                        ...parsed
                    });
                } catch (error) {
                    console.warn('Failed to parse saved reading settings:', error);
                }
            }
        }
    }["ReadingToolbar.useEffect"], []); // Apply settings to document root
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ReadingToolbar.useEffect": ()=>{
            const root = document.documentElement;
            // Apply CSS custom properties
            root.style.setProperty('--reading-font-scale', "".concat(settings.fontSize / 100));
            root.style.setProperty('--reading-line-height-scale', "".concat(settings.lineHeight / 100));
            root.style.setProperty('--reading-margin-scale', "".concat(settings.margins / 100));
            // Save to localStorage
            localStorage.setItem('mythoria-reading-settings', JSON.stringify(settings));
            // Notify parent component
            onSettingsChange === null || onSettingsChange === void 0 ? void 0 : onSettingsChange(settings);
        }
    }["ReadingToolbar.useEffect"], [
        settings,
        onSettingsChange
    ]);
    const updateSetting = (key, value)=>{
        setSettings((prev)=>({
                ...prev,
                [key]: value
            }));
    };
    const resetSettings = ()=>{
        setSettings(DEFAULT_SETTINGS);
    };
    const adjustValue = (key, delta)=>{
        setSettings((prev)=>({
                ...prev,
                [key]: Math.max(50, Math.min(200, prev[key] + delta))
            }));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "jsx-6cf89077993c11be" + " " + "reading-toolbar bg-base-200 border-b border-base-300 sticky top-0 z-50",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "jsx-6cf89077993c11be" + " " + "w-full max-w-[1200px] mx-auto",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-6cf89077993c11be" + " " + "flex items-center justify-between py-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setIsExpanded(!isExpanded),
                                "aria-label": tReadingToolbar('toggleLabel'),
                                className: "jsx-6cf89077993c11be" + " " + "btn btn-ghost btn-sm",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiType"], {
                                        className: "w-4 h-4"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ReadingToolbar.tsx",
                                        lineNumber: 109,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "jsx-6cf89077993c11be" + " " + "hidden sm:inline ml-2",
                                        children: tReadingToolbar('title')
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ReadingToolbar.tsx",
                                        lineNumber: 110,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ReadingToolbar.tsx",
                                lineNumber: 104,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-6cf89077993c11be" + " " + "flex items-center gap-2",
                                children: chapters.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "jsx-6cf89077993c11be" + " " + "dropdown dropdown-end",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            tabIndex: 0,
                                            role: "button",
                                            className: "jsx-6cf89077993c11be" + " " + "btn btn-ghost btn-sm",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiBook"], {
                                                    className: "w-4 h-4"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                    lineNumber: 119,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "jsx-6cf89077993c11be" + " " + "hidden sm:inline ml-2",
                                                    children: currentChapter === 0 ? tReadingToolbar('cover') : tReadingToolbar('chapterLabel', {
                                                        number: currentChapter
                                                    })
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                    lineNumber: 120,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "jsx-6cf89077993c11be" + " " + "sm:hidden ml-1",
                                                    children: currentChapter === 0 ? tReadingToolbar('cover') : tReadingToolbar('chapterLabel', {
                                                        number: currentChapter
                                                    })
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                    lineNumber: 123,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiChevronDown"], {
                                                    className: "w-3 h-3 ml-1"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                    lineNumber: 126,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/ReadingToolbar.tsx",
                                            lineNumber: 118,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                            tabIndex: 0,
                                            className: "jsx-6cf89077993c11be" + " " + "dropdown-content menu bg-base-100 rounded-box z-[1] w-52 p-2 shadow border border-base-300",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    className: "jsx-6cf89077993c11be",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>onChapterChange === null || onChapterChange === void 0 ? void 0 : onChapterChange(0),
                                                        className: "jsx-6cf89077993c11be" + " " + "".concat(currentChapter === 0 ? 'bg-primary/20' : ''),
                                                        children: tReadingToolbar('coverAndToc')
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                        lineNumber: 130,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                    lineNumber: 129,
                                                    columnNumber: 19
                                                }, this),
                                                chapters.map((chapter)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                        className: "jsx-6cf89077993c11be",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>onChapterChange === null || onChapterChange === void 0 ? void 0 : onChapterChange(chapter.chapterNumber),
                                                            className: "jsx-6cf89077993c11be" + " " + "".concat(currentChapter === chapter.chapterNumber ? 'bg-primary/20' : ''),
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "jsx-6cf89077993c11be" + " " + "font-medium",
                                                                    children: [
                                                                        "Ch. ",
                                                                        chapter.chapterNumber
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                                    lineNumber: 143,
                                                                    columnNumber: 25
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "jsx-6cf89077993c11be" + " " + "text-sm opacity-70 truncate",
                                                                    children: chapter.title
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                                    lineNumber: 144,
                                                                    columnNumber: 25
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                            lineNumber: 139,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, chapter.id, false, {
                                                        fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                        lineNumber: 138,
                                                        columnNumber: 21
                                                    }, this))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/components/ReadingToolbar.tsx",
                                            lineNumber: 128,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/ReadingToolbar.tsx",
                                    lineNumber: 117,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/ReadingToolbar.tsx",
                                lineNumber: 114,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ReadingToolbar.tsx",
                        lineNumber: 102,
                        columnNumber: 9
                    }, this),
                    "        ",
                    isExpanded && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-6cf89077993c11be" + " " + "border-t border-base-300 py-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-6cf89077993c11be" + " " + "grid grid-cols-1 md:grid-cols-3 gap-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-6cf89077993c11be" + " " + "flex items-center gap-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiType"], {
                                                className: "w-4 h-4 text-base-content/70"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                lineNumber: 158,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "jsx-6cf89077993c11be" + " " + "text-sm font-medium min-w-fit",
                                                children: tReadingToolbar('controls.fontSize')
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                lineNumber: 159,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-6cf89077993c11be" + " " + "flex items-center gap-2 flex-1",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>adjustValue('fontSize', -10),
                                                        disabled: settings.fontSize <= 50,
                                                        "aria-label": tReadingToolbar('controls.decreaseFontSize'),
                                                        className: "jsx-6cf89077993c11be" + " " + "btn btn-ghost btn-xs",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiMinus"], {
                                                            className: "w-3 h-3"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                            lineNumber: 167,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                        lineNumber: 161,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "jsx-6cf89077993c11be" + " " + "flex-1 mx-2",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "range",
                                                            min: "50",
                                                            max: "200",
                                                            step: "10",
                                                            value: settings.fontSize,
                                                            onChange: (e)=>updateSetting('fontSize', parseInt(e.target.value)),
                                                            "aria-label": tReadingToolbar('controls.fontSizeLabel'),
                                                            className: "jsx-6cf89077993c11be" + " " + "range range-primary range-xs"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                            lineNumber: 170,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                        lineNumber: 169,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>adjustValue('fontSize', 10),
                                                        disabled: settings.fontSize >= 200,
                                                        "aria-label": tReadingToolbar('controls.increaseFontSize'),
                                                        className: "jsx-6cf89077993c11be" + " " + "btn btn-ghost btn-xs",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiPlus"], {
                                                            className: "w-3 h-3"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                            lineNumber: 187,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                        lineNumber: 181,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "jsx-6cf89077993c11be" + " " + "text-xs min-w-fit",
                                                        children: [
                                                            settings.fontSize,
                                                            "%"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                        lineNumber: 189,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                lineNumber: 160,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/ReadingToolbar.tsx",
                                        lineNumber: 157,
                                        columnNumber: 15
                                    }, this),
                                    "              ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-6cf89077993c11be" + " " + "flex items-center gap-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiAlignJustify"], {
                                                className: "w-4 h-4 text-base-content/70"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                lineNumber: 194,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "jsx-6cf89077993c11be" + " " + "text-sm font-medium min-w-fit",
                                                children: tReadingToolbar('controls.lineHeight')
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                lineNumber: 195,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-6cf89077993c11be" + " " + "flex items-center gap-2 flex-1",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>adjustValue('lineHeight', -10),
                                                        disabled: settings.lineHeight <= 50,
                                                        "aria-label": tReadingToolbar('controls.decreaseLineHeight'),
                                                        className: "jsx-6cf89077993c11be" + " " + "btn btn-ghost btn-xs",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiMinus"], {
                                                            className: "w-3 h-3"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                            lineNumber: 203,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                        lineNumber: 197,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "jsx-6cf89077993c11be" + " " + "flex-1 mx-2",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "range",
                                                            min: "50",
                                                            max: "200",
                                                            step: "10",
                                                            value: settings.lineHeight,
                                                            onChange: (e)=>updateSetting('lineHeight', parseInt(e.target.value)),
                                                            "aria-label": tReadingToolbar('controls.lineHeightLabel'),
                                                            className: "jsx-6cf89077993c11be" + " " + "range range-secondary range-xs"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                            lineNumber: 206,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                        lineNumber: 205,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>adjustValue('lineHeight', 10),
                                                        disabled: settings.lineHeight >= 200,
                                                        "aria-label": tReadingToolbar('controls.increaseLineHeight'),
                                                        className: "jsx-6cf89077993c11be" + " " + "btn btn-ghost btn-xs",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiPlus"], {
                                                            className: "w-3 h-3"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                            lineNumber: 222,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                        lineNumber: 216,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "jsx-6cf89077993c11be" + " " + "text-xs min-w-fit",
                                                        children: [
                                                            settings.lineHeight,
                                                            "%"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                        lineNumber: 224,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                lineNumber: 196,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/ReadingToolbar.tsx",
                                        lineNumber: 193,
                                        columnNumber: 56
                                    }, this),
                                    "              ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-6cf89077993c11be" + " " + "flex items-center gap-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiMaximize2"], {
                                                className: "w-4 h-4 text-base-content/70"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                lineNumber: 229,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "jsx-6cf89077993c11be" + " " + "text-sm font-medium min-w-fit",
                                                children: tReadingToolbar('controls.margins')
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                lineNumber: 230,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-6cf89077993c11be" + " " + "flex items-center gap-2 flex-1",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>adjustValue('margins', -10),
                                                        disabled: settings.margins <= 50,
                                                        "aria-label": tReadingToolbar('controls.decreaseMargins'),
                                                        className: "jsx-6cf89077993c11be" + " " + "btn btn-ghost btn-xs",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiMinus"], {
                                                            className: "w-3 h-3"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                            lineNumber: 238,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                        lineNumber: 232,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "jsx-6cf89077993c11be" + " " + "flex-1 mx-2",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "range",
                                                            min: "50",
                                                            max: "200",
                                                            step: "10",
                                                            value: settings.margins,
                                                            onChange: (e)=>updateSetting('margins', parseInt(e.target.value)),
                                                            "aria-label": tReadingToolbar('controls.marginsLabel'),
                                                            className: "jsx-6cf89077993c11be" + " " + "range range-accent range-xs"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                            lineNumber: 241,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                        lineNumber: 240,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>adjustValue('margins', 10),
                                                        disabled: settings.margins >= 200,
                                                        "aria-label": tReadingToolbar('controls.increaseMargins'),
                                                        className: "jsx-6cf89077993c11be" + " " + "btn btn-ghost btn-xs",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiPlus"], {
                                                            className: "w-3 h-3"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                            lineNumber: 257,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                        lineNumber: 251,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "jsx-6cf89077993c11be" + " " + "text-xs min-w-fit",
                                                        children: [
                                                            settings.margins,
                                                            "%"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                        lineNumber: 259,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/ReadingToolbar.tsx",
                                                lineNumber: 231,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/ReadingToolbar.tsx",
                                        lineNumber: 228,
                                        columnNumber: 52
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ReadingToolbar.tsx",
                                lineNumber: 155,
                                columnNumber: 13
                            }, this),
                            "            ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-6cf89077993c11be" + " " + "flex justify-end mt-3 pt-3 border-t border-base-300",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: resetSettings,
                                    className: "jsx-6cf89077993c11be" + " " + "btn btn-outline btn-sm",
                                    children: tReadingToolbar('resetButton')
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ReadingToolbar.tsx",
                                    lineNumber: 265,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/ReadingToolbar.tsx",
                                lineNumber: 264,
                                columnNumber: 45
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ReadingToolbar.tsx",
                        lineNumber: 154,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ReadingToolbar.tsx",
                lineNumber: 101,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "6cf89077993c11be",
                children: ".reading-toolbar.jsx-6cf89077993c11be{transition:all .3s}.mythoria-story-content{margin:calc(var(--story-margins,1.5rem)*var(--reading-margin-scale,1));font-size:calc(var(--story-font-size,1rem)*var(--reading-font-scale,1))!important;line-height:calc(var(--story-line-height,1.5)*var(--reading-line-height-scale,1))!important}.mythoria-chapter-paragraph{font-size:calc(var(--story-font-size,1rem)*var(--reading-font-scale,1))!important;line-height:calc(var(--story-line-height,1.6)*var(--reading-line-height-scale,1))!important}.mythoria-chapter{margin:calc(var(--story-spacing,1.5rem)*var(--reading-margin-scale,1))0!important;padding:calc(var(--story-margins,1.5rem)*var(--reading-margin-scale,1))!important}.mythoria-story-title,.mythoria-chapter-title,.mythoria-toc-title{margin:calc(var(--story-spacing,1.5rem)*var(--reading-margin-scale,1))0!important}"
            }, void 0, false, void 0, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ReadingToolbar.tsx",
        lineNumber: 100,
        columnNumber: 5
    }, this);
}
_s(ReadingToolbar, "vgYbsQws2Hdu0N6Vp8pkF04rQ6k=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"]
    ];
});
_c = ReadingToolbar;
var _c;
__turbopack_context__.k.register(_c, "ReadingToolbar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/story-css.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Utility functions for story CSS template loading
__turbopack_context__.s([
    "AVAILABLE_AUDIENCES",
    ()=>AVAILABLE_AUDIENCES,
    "getStoryCSSPath",
    ()=>getStoryCSSPath,
    "loadStoryCSS",
    ()=>loadStoryCSS,
    "removeStoryCSS",
    ()=>removeStoryCSS
]);
function getStoryCSSPath(targetAudience) {
    // Return the path to the CSS file based only on target audience
    return "/templates/".concat(targetAudience, ".css");
}
function loadStoryCSS(targetAudience) {
    const cssPath = getStoryCSSPath(targetAudience);
    // Remove any existing story CSS
    const existingStyle = document.querySelector('style[data-story-css]');
    if (existingStyle) {
        existingStyle.remove();
    }
    // Load and scope the CSS
    fetch(cssPath).then((response)=>response.text()).then((css)=>{
        // Scope the CSS to only apply within .mythoria-story-scope
        const scopedCSS = css.replace(/([^{}]+)\s*\{/g, (match, selector)=>{
            // Skip @media queries and other at-rules
            if (selector.trim().startsWith('@')) {
                return match;
            }
            // Clean up selector
            const cleanSelector = selector.trim();
            // Add scoping prefix
            const scopedSelector = cleanSelector.split(',').map((s)=>".mythoria-story-scope ".concat(s.trim())).join(', ');
            return "".concat(scopedSelector, " {");
        });
        // Append variable-based overrides at the end so user controls can scale text regardless of template defaults
        const variableOverrides = "\n/* Mythoria runtime reading overrides (appended) */\n.mythoria-story-scope .mythoria-story-content { \n  font-size: calc(var(--story-font-size, 1rem) * var(--reading-font-scale, 1)) !important; \n  line-height: calc(var(--story-line-height, 1.5) * var(--reading-line-height-scale, 1)) !important; \n}\n.mythoria-story-scope .mythoria-chapter-content p {\n  font-size: calc(var(--story-font-size, 1rem) * var(--reading-font-scale, 1)) !important;\n  line-height: calc(var(--story-line-height, 1.6) * var(--reading-line-height-scale, 1)) !important;\n}\n";
        const finalCSS = "".concat(scopedCSS, "\n\n").concat(variableOverrides);
        // Create and append scoped CSS
        const style = document.createElement('style');
        style.textContent = finalCSS;
        style.setAttribute('data-story-css', 'true');
        document.head.appendChild(style);
    }).catch((error)=>{
        console.warn('Failed to load story CSS:', error);
    });
}
function removeStoryCSS() {
    const existingStyle = document.querySelector('style[data-story-css]');
    if (existingStyle) {
        existingStyle.remove();
    }
}
const AVAILABLE_AUDIENCES = [
    'children_0-2',
    'children_3-6',
    'children_7-10',
    'children_11-14',
    'young_adult_15-17',
    'adult_18+',
    'all_ages'
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/logo-mapping.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Utility functions for mapping story graphical styles to logo images
 */ __turbopack_context__.s([
    "getLogoFilename",
    ()=>getLogoFilename,
    "getLogoForGraphicalStyle",
    ()=>getLogoForGraphicalStyle
]);
/**
 * Maps graphical styles to their corresponding logo filenames
 */ const GRAPHICAL_STYLE_TO_LOGO = {
    cartoon: 'cartoon.jpg',
    realistic: 'realistic.jpg',
    watercolor: 'watercolor.jpg',
    digital_art: 'digital_art.jpg',
    hand_drawn: 'hand_drawn.jpg',
    minimalist: 'minimalist.jpg',
    vintage: 'vintage.jpg',
    comic_book: 'comic_book.jpg',
    anime: 'anime.jpg',
    pixar_style: 'pixar.jpg',
    disney_style: 'disney.jpg',
    sketch: 'sketch.jpg',
    oil_painting: 'oil-painting.jpg',
    colored_pencil: 'colored_pencil.jpg'
};
function getLogoForGraphicalStyle(graphicalStyle) {
    const baseUrl = 'https://mythoria.pt/images/logo/';
    if (!graphicalStyle) {
        return "".concat(baseUrl, "Logo.jpg"); // Default logo
    }
    const logoFilename = GRAPHICAL_STYLE_TO_LOGO[graphicalStyle];
    return "".concat(baseUrl).concat(logoFilename || 'Logo.jpg');
}
function getLogoFilename(graphicalStyle) {
    if (!graphicalStyle) {
        return 'Logo.jpg'; // Default logo
    }
    return GRAPHICAL_STYLE_TO_LOGO[graphicalStyle] || 'Logo.jpg';
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/utils/image-url.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Utility functions for handling image URLs
 * This is the centralized utility for all image URL handling in the application
 */ __turbopack_context__.s([
    "formatImageUrl",
    ()=>formatImageUrl,
    "toAbsoluteImageUrl",
    ()=>toAbsoluteImageUrl,
    "toRelativeImagePath",
    ()=>toRelativeImagePath
]);
const STORAGE_BASE_URL = 'https://storage.googleapis.com/mythoria-generated-stories';
function toAbsoluteImageUrl(relativePath) {
    if (!relativePath) return null;
    // If it's already an absolute URL, return as is
    if (relativePath.startsWith('http://') || relativePath.startsWith('https://')) {
        return relativePath;
    }
    // Convert relative path to absolute URL
    return "".concat(STORAGE_BASE_URL, "/").concat(relativePath);
}
const formatImageUrl = toAbsoluteImageUrl;
function toRelativeImagePath(absoluteUrl) {
    if (!absoluteUrl) return null;
    // If it's already a relative path, return as is
    if (!absoluteUrl.startsWith('http://') && !absoluteUrl.startsWith('https://')) {
        return absoluteUrl;
    }
    // Convert absolute URL to relative path
    if (absoluteUrl.startsWith(STORAGE_BASE_URL)) {
        return absoluteUrl.replace("".concat(STORAGE_BASE_URL, "/"), '');
    }
    // If it's an external URL, return as is
    return absoluteUrl;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/StoryReader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StoryReader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ReadingToolbar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ReadingToolbar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$story$2d$css$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/story-css.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logo$2d$mapping$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/logo-mapping.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$image$2d$url$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/image-url.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
function StoryReader(param) {
    let { storyId, story, chapters, currentChapter } = param;
    _s();
    const tStoryReader = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])('StoryReader');
    const tActions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])('Actions');
    const tAltTexts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])('AltTexts');
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [readingSettings, setReadingSettings] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isContentLoaded, setIsContentLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showTableOfContents, setShowTableOfContents] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Determine what to show based on current chapter
    const isFirstPage = !currentChapter || currentChapter === 0;
    const currentChapterData = currentChapter ? chapters.find((ch)=>ch.chapterNumber === currentChapter) : null;
    const totalChapters = chapters.length;
    // Load appropriate CSS theme based on story metadata
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StoryReader.useEffect": ()=>{
            if (story === null || story === void 0 ? void 0 : story.targetAudience) {
                try {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$story$2d$css$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadStoryCSS"])(story.targetAudience);
                } catch (error) {
                    console.warn('Failed to load story CSS, using default styles:', error);
                    // Fall back to a default audience style
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$story$2d$css$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadStoryCSS"])('all_ages');
                }
            }
            return ({
                "StoryReader.useEffect": ()=>{
                    // Clean up CSS when component unmounts
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$story$2d$css$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeStoryCSS"])();
                }
            })["StoryReader.useEffect"];
        }
    }["StoryReader.useEffect"], [
        story
    ]);
    // Mark content as loaded after a short delay to ensure CSS is applied
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "StoryReader.useEffect": ()=>{
            const timer = setTimeout({
                "StoryReader.useEffect.timer": ()=>{
                    setIsContentLoaded(true);
                }
            }["StoryReader.useEffect.timer"], 100);
            return ({
                "StoryReader.useEffect": ()=>clearTimeout(timer)
            })["StoryReader.useEffect"];
        }
    }["StoryReader.useEffect"], []);
    // Handle reading settings changes
    const handleReadingSettingsChange = (settings)=>{
        setReadingSettings(settings);
    };
    // Navigation functions
    const navigateToChapter = (chapterNumber)=>{
        // Helper to build locale-aware base path for a public story
        const buildPublicStoryBase = ()=>{
            var _segments_idx;
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            const segments = window.location.pathname.split('/').filter(Boolean);
            // Patterns: /<locale>/p/<slug>(/...) OR /p/<slug>(/...)
            let localePrefix = '';
            let idx = 0;
            if ((_segments_idx = segments[idx]) === null || _segments_idx === void 0 ? void 0 : _segments_idx.match(/^[a-z]{2}-[A-Z]{2}$/)) {
                localePrefix = "/".concat(segments[idx]);
                idx++;
            }
            if (segments[idx] !== 'p') return '';
            const slugSeg = segments[idx + 1];
            if (!slugSeg) return '';
            return "".concat(localePrefix, "/p/").concat(slugSeg);
        };
        if (chapterNumber === 0) {
            // Navigate to first page
            if (window.location.pathname.includes('/p/')) {
                // Public story navigation (preserve locale if present)
                const base = buildPublicStoryBase();
                if (base) {
                    router.push(base);
                } else {
                    // Fallback to previous logic if parsing fails
                    const slug = window.location.pathname.split('/p/')[1].split('/')[0];
                    router.push("/p/".concat(slug));
                }
            } else {
                // Private story navigation
                router.push("/stories/read/".concat(storyId));
            }
        } else {
            // Navigate to specific chapter
            if (window.location.pathname.includes('/p/')) {
                // Public story navigation (preserve locale if present)
                const base = buildPublicStoryBase();
                if (base) {
                    router.push("".concat(base, "/chapter/").concat(chapterNumber));
                } else {
                    const slug = window.location.pathname.split('/p/')[1].split('/')[0];
                    router.push("/p/".concat(slug, "/chapter/").concat(chapterNumber));
                }
            } else {
                // Private story navigation
                router.push("/stories/read/".concat(storyId, "/chapter/").concat(chapterNumber));
            }
        }
    };
    const navigateToNextChapter = ()=>{
        if (isFirstPage) {
            navigateToChapter(1);
        } else if (currentChapter && currentChapter < totalChapters) {
            navigateToChapter(currentChapter + 1);
        }
    };
    const navigateToPreviousChapter = ()=>{
        if (currentChapter && currentChapter > 1) {
            navigateToChapter(currentChapter - 1);
        } else if (currentChapter === 1) {
            navigateToChapter(0); // Go to first page
        }
    };
    // Get logo URL based on graphical style
    const logoUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$logo$2d$mapping$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLogoForGraphicalStyle"])(story.graphicalStyle);
    // Render first page content
    const renderFirstPage = ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "story-container",
            children: [
                story.coverUri && (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$image$2d$url$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toAbsoluteImageUrl"])(story.coverUri) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mythoria-front-cover",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                src: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$image$2d$url$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toAbsoluteImageUrl"])(story.coverUri),
                                alt: "Book Front Cover",
                                className: "mythoria-cover-image",
                                width: 400,
                                height: 600
                            }, void 0, false, {
                                fileName: "[project]/src/components/StoryReader.tsx",
                                lineNumber: 169,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/StoryReader.tsx",
                            lineNumber: 168,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mythoria-page-break"
                        }, void 0, false, {
                            fileName: "[project]/src/components/StoryReader.tsx",
                            lineNumber: 177,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true),
                story.dedicationMessage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mythoria-dedicatory",
                    children: story.dedicationMessage
                }, void 0, false, {
                    fileName: "[project]/src/components/StoryReader.tsx",
                    lineNumber: 183,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mythoria-author-name",
                    children: tStoryReader('byAuthor', {
                        authorName: story.authorName
                    })
                }, void 0, false, {
                    fileName: "[project]/src/components/StoryReader.tsx",
                    lineNumber: 187,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mythoria-message",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mythoria-message-text",
                            children: [
                                tStoryReader('storyImaginedBy'),
                                " ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                                    className: "mythoria-author-emphasis",
                                    children: story.authorName
                                }, void 0, false, {
                                    fileName: "[project]/src/components/StoryReader.tsx",
                                    lineNumber: 192,
                                    columnNumber: 45
                                }, this),
                                tStoryReader('storyImaginedByEnd')
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/StoryReader.tsx",
                            lineNumber: 191,
                            columnNumber: 9
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mythoria-message-text",
                            children: tStoryReader('craftedWith')
                        }, void 0, false, {
                            fileName: "[project]/src/components/StoryReader.tsx",
                            lineNumber: 194,
                            columnNumber: 9
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mythoria-logo-wrapper w-full flex justify-center px-2 sm:px-0",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                src: logoUrl,
                                alt: "Mythoria Logo",
                                className: "mythoria-logo max-w-full h-auto",
                                width: 400,
                                height: 200,
                                // Provide responsive sizing hints: use ~80vw on very small screens, up to intrinsic 400px
                                sizes: "(max-width: 480px) 80vw, (max-width: 768px) 60vw, 400px",
                                // Force responsive scaling (Next.js respects explicit style width/height over intrinsic wrapper width)
                                style: {
                                    width: '100%',
                                    height: 'auto',
                                    maxWidth: '400px'
                                },
                                priority: true
                            }, void 0, false, {
                                fileName: "[project]/src/components/StoryReader.tsx",
                                lineNumber: 197,
                                columnNumber: 11
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/StoryReader.tsx",
                            lineNumber: 196,
                            columnNumber: 9
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/StoryReader.tsx",
                    lineNumber: 190,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mythoria-page-break"
                }, void 0, false, {
                    fileName: "[project]/src/components/StoryReader.tsx",
                    lineNumber: 212,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mythoria-table-of-contents",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "mythoria-toc-title",
                            children: tStoryReader('tableOfContents')
                        }, void 0, false, {
                            fileName: "[project]/src/components/StoryReader.tsx",
                            lineNumber: 216,
                            columnNumber: 9
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                            className: "mythoria-toc-list",
                            children: chapters.map((chapter)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                    className: "mythoria-toc-item",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>navigateToChapter(chapter.chapterNumber),
                                        className: "mythoria-toc-link",
                                        children: [
                                            chapter.chapterNumber,
                                            ". ",
                                            chapter.title
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/StoryReader.tsx",
                                        lineNumber: 220,
                                        columnNumber: 15
                                    }, this)
                                }, chapter.id, false, {
                                    fileName: "[project]/src/components/StoryReader.tsx",
                                    lineNumber: 219,
                                    columnNumber: 13
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/components/StoryReader.tsx",
                            lineNumber: 217,
                            columnNumber: 9
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/StoryReader.tsx",
                    lineNumber: 215,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mythoria-page-break"
                }, void 0, false, {
                    fileName: "[project]/src/components/StoryReader.tsx",
                    lineNumber: 231,
                    columnNumber: 7
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-center py-8",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>navigateToChapter(1),
                                className: "btn btn-primary btn-lg",
                                disabled: chapters.length === 0,
                                children: tStoryReader('startReading')
                            }, void 0, false, {
                                fileName: "[project]/src/components/StoryReader.tsx",
                                lineNumber: 236,
                                columnNumber: 11
                            }, this),
                            story.hasAudio && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    // Navigate to listen page
                                    if (window.location.pathname.includes('/p/')) {
                                        var _segments_idx;
                                        // Public story navigation (preserve locale if present)
                                        const segments = window.location.pathname.split('/').filter(Boolean);
                                        let idx = 0;
                                        let localePrefix = '';
                                        if ((_segments_idx = segments[idx]) === null || _segments_idx === void 0 ? void 0 : _segments_idx.match(/^[a-z]{2}-[A-Z]{2}$/)) {
                                            localePrefix = "/".concat(segments[idx]);
                                            idx++;
                                        }
                                        if (segments[idx] === 'p') {
                                            const slug = segments[idx + 1];
                                            if (slug) {
                                                router.push("".concat(localePrefix, "/p/").concat(slug, "/listen"));
                                                return;
                                            }
                                        }
                                        // Fallback
                                        const slug = window.location.pathname.split('/p/')[1].split('/')[0];
                                        router.push("/p/".concat(slug, "/listen"));
                                    } else {
                                        // Private story navigation
                                        router.push("/stories/listen/".concat(storyId));
                                    }
                                },
                                className: "btn btn-outline btn-primary btn-lg flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiVolume2"], {
                                        className: "w-5 h-5"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/StoryReader.tsx",
                                        lineNumber: 275,
                                        columnNumber: 15
                                    }, this),
                                    tStoryReader('listen')
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/StoryReader.tsx",
                                lineNumber: 246,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/StoryReader.tsx",
                        lineNumber: 235,
                        columnNumber: 9
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/StoryReader.tsx",
                    lineNumber: 234,
                    columnNumber: 7
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/StoryReader.tsx",
            lineNumber: 163,
            columnNumber: 5
        }, this);
    // Render chapter content
    const renderChapter = ()=>{
        if (!currentChapterData) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "story-container",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-center py-16",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-2xl font-bold mb-4",
                            children: tStoryReader('chapterNotFound')
                        }, void 0, false, {
                            fileName: "[project]/src/components/StoryReader.tsx",
                            lineNumber: 290,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-lg text-base-content/70 mb-6",
                            children: tStoryReader('chapterNotFoundDescription')
                        }, void 0, false, {
                            fileName: "[project]/src/components/StoryReader.tsx",
                            lineNumber: 291,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>navigateToChapter(0),
                            className: "btn btn-primary",
                            children: tStoryReader('backToStory')
                        }, void 0, false, {
                            fileName: "[project]/src/components/StoryReader.tsx",
                            lineNumber: 294,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/StoryReader.tsx",
                    lineNumber: 289,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/StoryReader.tsx",
                lineNumber: 288,
                columnNumber: 9
            }, this);
        }
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "story-container",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mythoria-chapter",
                    id: "chapter-".concat(currentChapterData.chapterNumber),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "mythoria-chapter-title",
                            children: currentChapterData.title
                        }, void 0, false, {
                            fileName: "[project]/src/components/StoryReader.tsx",
                            lineNumber: 308,
                            columnNumber: 11
                        }, this),
                        currentChapterData.imageUri && (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$image$2d$url$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toAbsoluteImageUrl"])(currentChapterData.imageUri) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mythoria-chapter-image",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                src: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$image$2d$url$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toAbsoluteImageUrl"])(currentChapterData.imageUri),
                                alt: tAltTexts('chapterIllustration', {
                                    number: currentChapterData.chapterNumber
                                }),
                                className: "mythoria-chapter-img",
                                width: 600,
                                height: 400
                            }, void 0, false, {
                                fileName: "[project]/src/components/StoryReader.tsx",
                                lineNumber: 313,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/StoryReader.tsx",
                            lineNumber: 312,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mythoria-chapter-content",
                            dangerouslySetInnerHTML: {
                                __html: currentChapterData.htmlContent
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/components/StoryReader.tsx",
                            lineNumber: 324,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/StoryReader.tsx",
                    lineNumber: 307,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mythoria-page-break"
                }, void 0, false, {
                    fileName: "[project]/src/components/StoryReader.tsx",
                    lineNumber: 331,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex justify-between items-center py-2 px-4 md:px-2 gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex-shrink-0",
                            children: currentChapter && currentChapter > 1 || currentChapter === 1 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: navigateToPreviousChapter,
                                className: "btn btn-outline btn-sm text-xs md:text-sm",
                                children: currentChapter === 1 ? '← Back' : "← Ch. ".concat(currentChapter - 1)
                            }, void 0, false, {
                                fileName: "[project]/src/components/StoryReader.tsx",
                                lineNumber: 337,
                                columnNumber: 15
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {}, void 0, false, {
                                fileName: "[project]/src/components/StoryReader.tsx",
                                lineNumber: 344,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/StoryReader.tsx",
                            lineNumber: 335,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center flex-shrink-0 min-w-0",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-xs md:text-sm text-base-content/70 whitespace-nowrap",
                                children: [
                                    "Ch. ",
                                    currentChapter,
                                    " of ",
                                    totalChapters
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/StoryReader.tsx",
                                lineNumber: 349,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/StoryReader.tsx",
                            lineNumber: 348,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex-shrink-0",
                            children: currentChapter && currentChapter < totalChapters ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: navigateToNextChapter,
                                className: "btn btn-primary btn-sm text-xs md:text-sm",
                                children: [
                                    "Ch. ",
                                    currentChapter + 1,
                                    " →"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/StoryReader.tsx",
                                lineNumber: 356,
                                columnNumber: 15
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {}, void 0, false, {
                                fileName: "[project]/src/components/StoryReader.tsx",
                                lineNumber: 363,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/StoryReader.tsx",
                            lineNumber: 354,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/StoryReader.tsx",
                    lineNumber: 334,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/StoryReader.tsx",
            lineNumber: 306,
            columnNumber: 7
        }, this);
    };
    // Table of Contents Modal
    const renderTableOfContentsModal = ()=>showTableOfContents && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "modal modal-open",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "modal-box",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "font-bold text-lg mb-4",
                        children: tStoryReader('tableOfContents')
                    }, void 0, false, {
                        fileName: "[project]/src/components/StoryReader.tsx",
                        lineNumber: 376,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                        className: "space-y-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>{
                                        navigateToChapter(0);
                                        setShowTableOfContents(false);
                                    },
                                    className: "btn btn-ghost btn-sm w-full justify-start",
                                    children: tStoryReader('coverAndIntroduction')
                                }, void 0, false, {
                                    fileName: "[project]/src/components/StoryReader.tsx",
                                    lineNumber: 379,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/StoryReader.tsx",
                                lineNumber: 378,
                                columnNumber: 13
                            }, this),
                            chapters.map((chapter)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>{
                                            navigateToChapter(chapter.chapterNumber);
                                            setShowTableOfContents(false);
                                        },
                                        className: "btn btn-ghost btn-sm w-full justify-start ".concat(currentChapter === chapter.chapterNumber ? 'bg-primary/20' : ''),
                                        children: [
                                            chapter.chapterNumber,
                                            ". ",
                                            chapter.title
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/StoryReader.tsx",
                                        lineNumber: 391,
                                        columnNumber: 17
                                    }, this)
                                }, chapter.id, false, {
                                    fileName: "[project]/src/components/StoryReader.tsx",
                                    lineNumber: 390,
                                    columnNumber: 15
                                }, this))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/StoryReader.tsx",
                        lineNumber: 377,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "modal-action",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>setShowTableOfContents(false),
                            className: "btn btn-sm",
                            children: tActions('close')
                        }, void 0, false, {
                            fileName: "[project]/src/components/StoryReader.tsx",
                            lineNumber: 406,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/StoryReader.tsx",
                        lineNumber: 405,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/StoryReader.tsx",
                lineNumber: 375,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/components/StoryReader.tsx",
            lineNumber: 374,
            columnNumber: 7
        }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "jsx-78c4be15d5b9d44f" + " " + "story-reader min-h-screen px-0 bg-base-100",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ReadingToolbar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                onSettingsChange: handleReadingSettingsChange,
                chapters: chapters,
                currentChapter: currentChapter || 0,
                onChapterChange: navigateToChapter
            }, void 0, false, {
                fileName: "[project]/src/components/StoryReader.tsx",
                lineNumber: 421,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    // Provide CSS variables as fallbacks for dynamic scaling if templates use them
                    // Note: concrete font-size/line-height are controlled via CSS overrides and variables
                    ...{
                        '--reading-font-scale': (readingSettings === null || readingSettings === void 0 ? void 0 : readingSettings.fontSize) ? String(readingSettings.fontSize / 100) : undefined,
                        '--reading-line-height-scale': (readingSettings === null || readingSettings === void 0 ? void 0 : readingSettings.lineHeight) ? String(readingSettings.lineHeight / 100) : undefined,
                        '--reading-margin-scale': (readingSettings === null || readingSettings === void 0 ? void 0 : readingSettings.margins) ? String(readingSettings.margins / 100) : undefined
                    }
                },
                className: "jsx-78c4be15d5b9d44f" + " " + "mythoria-story-scope",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "jsx-78c4be15d5b9d44f" + " " + "w-full px-0 md:px-0 py-0",
                    children: !isContentLoaded ? // Loading state
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-78c4be15d5b9d44f" + " " + "flex flex-col items-center justify-center py-16",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-78c4be15d5b9d44f" + " " + "loading loading-spinner loading-lg mb-4"
                            }, void 0, false, {
                                fileName: "[project]/src/components/StoryReader.tsx",
                                lineNumber: 445,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "jsx-78c4be15d5b9d44f" + " " + "text-lg text-base-content/70",
                                children: tStoryReader('preparing')
                            }, void 0, false, {
                                fileName: "[project]/src/components/StoryReader.tsx",
                                lineNumber: 446,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/StoryReader.tsx",
                        lineNumber: 444,
                        columnNumber: 13
                    }, this) : // Story content
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                        className: "jsx-78c4be15d5b9d44f" + " " + "mythoria-story-content prose prose-lg max-w-none p-0 md:p-0 m-0",
                        children: isFirstPage ? renderFirstPage() : renderChapter()
                    }, void 0, false, {
                        fileName: "[project]/src/components/StoryReader.tsx",
                        lineNumber: 450,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/StoryReader.tsx",
                    lineNumber: 441,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/StoryReader.tsx",
                lineNumber: 429,
                columnNumber: 7
            }, this),
            renderTableOfContentsModal(),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "78c4be15d5b9d44f",
                children: ".story-reader.jsx-78c4be15d5b9d44f{transition:all .3s}.mythoria-story-content.prose{max-width:none;color:inherit}.mythoria-toc-link.jsx-78c4be15d5b9d44f{color:inherit;cursor:pointer;font:inherit;background:0 0;border:none;padding:0;text-decoration:underline}.mythoria-toc-link.jsx-78c4be15d5b9d44f:hover{color:#06c}"
            }, void 0, false, void 0, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/StoryReader.tsx",
        lineNumber: 419,
        columnNumber: 5
    }, this);
}
_s(StoryReader, "3oFdhWDyV8NzGVbiSumX4nPeUU8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = StoryReader;
var _c;
__turbopack_context__.k.register(_c, "StoryReader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/app/[locale]/p/[slug]/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PublicStoryPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/use-intl/dist/esm/development/react.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PublicStoryRating$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/PublicStoryRating.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$StoryReader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/StoryReader.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$date$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/date.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
function PublicStoryPage() {
    _s();
    const params = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"])();
    const locale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLocale"])();
    const tPublicStoryPage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])("PublicStoryPage");
    const tActions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])("Actions");
    const tGetInspiredPage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])("GetInspiredPage");
    var _params_slug_, _ref;
    const slug = Array.isArray(params === null || params === void 0 ? void 0 : params.slug) ? (_params_slug_ = params === null || params === void 0 ? void 0 : params.slug[0]) !== null && _params_slug_ !== void 0 ? _params_slug_ : "" : (_ref = params === null || params === void 0 ? void 0 : params.slug) !== null && _ref !== void 0 ? _ref : "";
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PublicStoryPage.useEffect": ()=>{
            if (!slug) return;
            const fetchPublicStory = {
                "PublicStoryPage.useEffect.fetchPublicStory": async ()=>{
                    try {
                        const response = await fetch("/api/p/".concat(slug));
                        if (!response.ok) {
                            const errorText = await response.text();
                            console.error("[Public Page] Response error:", errorText);
                            throw new Error("HTTP error! status: ".concat(response.status, ", message: ").concat(errorText));
                        }
                        const result = await response.json();
                        console.log("[Public Page] Response data:", result);
                        if (result.success) {
                            // Story data fetched successfully
                            setData(result);
                        } else {
                            console.error("[Public Page] API returned error:", result.error);
                            setError(result.error || tPublicStoryPage("errors.notFound"));
                        }
                    } catch (err) {
                        console.error("[Public Page] Error fetching public story:", err);
                        const errorMessage = err instanceof Error ? err.message : "Unknown error";
                        setError("".concat(tPublicStoryPage("errors.failedToLoadStory"), ": ").concat(errorMessage));
                    } finally{
                        setLoading(false);
                    }
                }
            }["PublicStoryPage.useEffect.fetchPublicStory"];
            fetchPublicStory();
        }
    }["PublicStoryPage.useEffect"], [
        slug,
        tPublicStoryPage
    ]);
    // Generate metadata for the page
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PublicStoryPage.useEffect": ()=>{
            if (data === null || data === void 0 ? void 0 : data.story) {
                const story = data.story;
                // Set page title directly with the format "StoryTitle | Mythoria"
                document.title = "".concat(story.title, " | Mythoria");
                // Set meta description
                const metaDescription = document.querySelector('meta[name="description"]');
                const description = story.synopsis || story.plotDescription || tPublicStoryPage("metadata.defaultDescription", {
                    title: story.title
                });
                if (metaDescription) {
                    metaDescription.setAttribute("content", description);
                } else {
                    const meta = document.createElement("meta");
                    meta.name = "description";
                    meta.content = description;
                    document.head.appendChild(meta);
                }
                // Set Open Graph tags
                const setMetaTag = {
                    "PublicStoryPage.useEffect.setMetaTag": (property, content)=>{
                        let meta = document.querySelector('meta[property="'.concat(property, '"]'));
                        if (!meta) {
                            meta = document.createElement("meta");
                            meta.setAttribute("property", property);
                            document.head.appendChild(meta);
                        }
                        meta.setAttribute("content", content);
                    }
                }["PublicStoryPage.useEffect.setMetaTag"];
                const baseUrl = window.location.origin;
                setMetaTag("og:title", "".concat(story.title, " | Mythoria"));
                setMetaTag("og:description", description);
                setMetaTag("og:type", "article");
                setMetaTag("og:url", window.location.href);
                setMetaTag("og:site_name", "Mythoria");
                setMetaTag("og:image", "".concat(baseUrl, "/api/og/story/").concat(slug));
                setMetaTag("og:image:width", "1200");
                setMetaTag("og:image:height", "630");
                setMetaTag("og:image:alt", tPublicStoryPage("metadata.coverImageAlt", {
                    title: story.title
                }));
                // Twitter Card tags
                const setTwitterTag = {
                    "PublicStoryPage.useEffect.setTwitterTag": (name, content)=>{
                        let meta = document.querySelector('meta[name="'.concat(name, '"]'));
                        if (!meta) {
                            meta = document.createElement("meta");
                            meta.setAttribute("name", name);
                            document.head.appendChild(meta);
                        }
                        meta.setAttribute("content", content);
                    }
                }["PublicStoryPage.useEffect.setTwitterTag"];
                setTwitterTag("twitter:card", "summary_large_image");
                setTwitterTag("twitter:title", "".concat(story.title, " | Mythoria"));
                setTwitterTag("twitter:description", description);
                setTwitterTag("twitter:image", "".concat(baseUrl, "/api/og/story/").concat(slug));
            }
        }
    }["PublicStoryPage.useEffect"], [
        data,
        slug,
        tPublicStoryPage
    ]);
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-screen flex items-center justify-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center space-y-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiLoader"], {
                        className: "animate-spin text-4xl text-primary mx-auto"
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                        lineNumber: 188,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-xl font-semibold",
                        children: tPublicStoryPage("loading.title")
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                        lineNumber: 189,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-600",
                        children: tPublicStoryPage("loading.subtitle")
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                        lineNumber: 192,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                lineNumber: 187,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
            lineNumber: 186,
            columnNumber: 7
        }, this);
    }
    if (error || !data) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-screen flex items-center justify-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center space-y-4 max-w-md mx-auto px-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiAlertCircle"], {
                        className: "text-4xl text-red-500 mx-auto"
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                        lineNumber: 203,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-xl font-semibold text-gray-900",
                        children: tPublicStoryPage("errors.notFound")
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                        lineNumber: 204,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-600",
                        children: error || tPublicStoryPage("errors.notFoundDesc")
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                        lineNumber: 207,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            href: "/".concat(locale),
                            className: "btn btn-primary btn-sm",
                            children: tActions("goToHomepage")
                        }, void 0, false, {
                            fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                            lineNumber: 212,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                        lineNumber: 211,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                lineNumber: 202,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
            lineNumber: 201,
            columnNumber: 7
        }, this);
    }
    const { story } = data;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "jsx-66a2690013a77b21" + " " + "min-h-screen bg-gray-50",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "jsx-66a2690013a77b21" + " " + "bg-white shadow-sm border-b",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "jsx-66a2690013a77b21" + " " + "container mx-auto px-4 py-6",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-66a2690013a77b21" + " " + "max-w-4xl mx-auto",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-66a2690013a77b21" + " " + "flex flex-col gap-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                        className: "jsx-66a2690013a77b21" + " " + "text-3xl font-bold text-gray-900",
                                        children: story.title
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                        lineNumber: 231,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-66a2690013a77b21" + " " + "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "jsx-66a2690013a77b21" + " " + "flex flex-wrap items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                    href: "/".concat(locale, "/stories/print/").concat(story.storyId),
                                                    className: "jsx-66a2690013a77b21" + " " + "btn btn-primary btn-sm flex items-center gap-2 text-xs sm:text-sm",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiPrinter"], {
                                                            className: "w-3 h-3 sm:w-4 sm:h-4"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                                            lineNumber: 243,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "jsx-66a2690013a77b21" + " " + "hidden min-[480px]:inline",
                                                            children: tPublicStoryPage("actions.orderPrint")
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                                            lineNumber: 244,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "jsx-66a2690013a77b21" + " " + "min-[480px]:hidden",
                                                            children: tPublicStoryPage("actions.print")
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                                            lineNumber: 247,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                                    lineNumber: 239,
                                                    columnNumber: 19
                                                }, this),
                                                story.hasAudio && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                    href: "/".concat(locale, "/p/").concat(slug, "/listen"),
                                                    className: "jsx-66a2690013a77b21" + " " + "btn btn-secondary btn-sm flex items-center gap-2 text-xs sm:text-sm",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiVolume2"], {
                                                            className: "w-3 h-3 sm:w-4 sm:h-4"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                                            lineNumber: 256,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "jsx-66a2690013a77b21" + " " + "hidden min-[480px]:inline",
                                                            children: tPublicStoryPage("actions.listen")
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                                            lineNumber: 257,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "jsx-66a2690013a77b21" + " " + "min-[480px]:hidden",
                                                            children: tPublicStoryPage("actions.listenMobile")
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                                            lineNumber: 260,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                                    lineNumber: 252,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                            lineNumber: 238,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                        lineNumber: 236,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                lineNumber: 229,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-66a2690013a77b21" + " " + "flex flex-wrap items-center gap-4 text-sm text-gray-600 mt-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-66a2690013a77b21" + " " + "flex items-center gap-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiUser"], {}, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                                lineNumber: 271,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "jsx-66a2690013a77b21",
                                                children: [
                                                    tPublicStoryPage("labels.by"),
                                                    " ",
                                                    story.authorName || tPublicStoryPage("labels.unknownAuthor")
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                                lineNumber: 272,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                        lineNumber: 270,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-66a2690013a77b21" + " " + "flex items-center gap-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCalendar"], {}, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                                lineNumber: 278,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "jsx-66a2690013a77b21",
                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$date$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatDate"])(story.createdAt, {
                                                    locale
                                                })
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                                lineNumber: 279,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                        lineNumber: 277,
                                        columnNumber: 15
                                    }, this),
                                    story.targetAudience && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-66a2690013a77b21" + " " + "flex items-center gap-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiTag"], {}, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                                lineNumber: 283,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "jsx-66a2690013a77b21",
                                                children: tGetInspiredPage("targetAudience.".concat(story.targetAudience)) || story.targetAudience.replace("_", " ")
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                                lineNumber: 284,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                        lineNumber: 282,
                                        columnNumber: 17
                                    }, this),
                                    story.graphicalStyle && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-66a2690013a77b21" + " " + "flex items-center gap-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiEye"], {}, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                                lineNumber: 294,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "jsx-66a2690013a77b21",
                                                children: tGetInspiredPage("graphicalStyle.".concat(story.graphicalStyle)) || story.graphicalStyle.replace("_", " ")
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                                lineNumber: 295,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                        lineNumber: 293,
                                        columnNumber: 17
                                    }, this),
                                    story.novelStyle && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-66a2690013a77b21" + " " + "flex items-center gap-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiTag"], {}, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                                lineNumber: 305,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "jsx-66a2690013a77b21",
                                                children: tGetInspiredPage("novelStyle.".concat(story.novelStyle)) || story.novelStyle.replace("_", " ")
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                                lineNumber: 306,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                        lineNumber: 304,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                lineNumber: 269,
                                columnNumber: 13
                            }, this),
                            (story.synopsis || story.plotDescription) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-66a2690013a77b21" + " " + "mt-4 p-4 bg-gray-50 rounded-lg",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "jsx-66a2690013a77b21" + " " + "font-bold text-gray-900 mb-2",
                                        children: tPublicStoryPage("labels.synopsis")
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                        lineNumber: 316,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "jsx-66a2690013a77b21" + " " + "text-gray-700 leading-relaxed text-sm",
                                        children: story.synopsis || story.plotDescription
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                        lineNumber: 319,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                lineNumber: 315,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                        lineNumber: 228,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                    lineNumber: 227,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                lineNumber: 226,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "jsx-66a2690013a77b21" + " " + "py-6",
                children: [
                    (data === null || data === void 0 ? void 0 : data.chapters) && data.chapters.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$StoryReader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        storyId: story.storyId,
                        story: {
                            title: story.title,
                            authorName: story.authorName,
                            dedicationMessage: story.dedicationMessage,
                            targetAudience: story.targetAudience,
                            graphicalStyle: story.graphicalStyle,
                            coverUri: story.coverUri,
                            backcoverUri: story.backcoverUri,
                            hasAudio: story.hasAudio
                        },
                        chapters: data.chapters,
                        currentChapter: 0
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                        lineNumber: 331,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-66a2690013a77b21" + " " + "container mx-auto px-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "jsx-66a2690013a77b21" + " " + "max-w-4xl mx-auto",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-66a2690013a77b21" + " " + "bg-white rounded-lg shadow-sm border p-8 text-center",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiAlertCircle"], {
                                        className: "text-4xl text-gray-400 mx-auto mb-4"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                        lineNumber: 350,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "jsx-66a2690013a77b21" + " " + "text-lg font-medium text-gray-900 mb-2",
                                        children: tPublicStoryPage("errors.contentNotAvailable")
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                        lineNumber: 351,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "jsx-66a2690013a77b21" + " " + "text-gray-600",
                                        children: tPublicStoryPage("errors.contentNotAvailableDesc")
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                        lineNumber: 354,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                lineNumber: 349,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                            lineNumber: 348,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                        lineNumber: 347,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-66a2690013a77b21" + " " + "container mx-auto px-4 mt-8",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "jsx-66a2690013a77b21" + " " + "max-w-4xl mx-auto",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-66a2690013a77b21" + " " + "bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-6 border border-blue-200 print:hidden",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "jsx-66a2690013a77b21" + " " + "text-xl font-bold text-gray-900 mb-3 text-center",
                                        children: tPublicStoryPage("storyComplete.enjoyedTitle")
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                        lineNumber: 366,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "jsx-66a2690013a77b21" + " " + "text-gray-700 text-center mb-6",
                                        children: tPublicStoryPage("storyComplete.enjoyedDesc")
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                        lineNumber: 369,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-66a2690013a77b21" + " " + "flex flex-col sm:flex-row gap-4 justify-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: "/".concat(locale),
                                                className: "jsx-66a2690013a77b21" + " " + "btn btn-primary flex items-center gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiEdit3"], {
                                                        className: "w-4 h-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                                        lineNumber: 378,
                                                        columnNumber: 19
                                                    }, this),
                                                    tPublicStoryPage("actions.createOwnStory")
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                                lineNumber: 374,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: "/".concat(locale, "/stories/print/").concat(story.storyId),
                                                className: "jsx-66a2690013a77b21" + " " + "btn btn-secondary flex items-center gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiPrinter"], {
                                                        className: "w-4 h-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                                        lineNumber: 386,
                                                        columnNumber: 19
                                                    }, this),
                                                    tPublicStoryPage("actions.orderPrintedBook")
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                                lineNumber: 382,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                        lineNumber: 373,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                lineNumber: 365,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                            lineNumber: 364,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                        lineNumber: 363,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-66a2690013a77b21" + " " + "container mx-auto px-4 mt-8",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "jsx-66a2690013a77b21" + " " + "max-w-4xl mx-auto",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$PublicStoryRating$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                storyId: story.storyId,
                                onRatingSubmitted: (rating)=>{
                                    console.log("Rating submitted:", rating);
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                                lineNumber: 397,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                            lineNumber: 396,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                        lineNumber: 395,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
                lineNumber: 329,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "66a2690013a77b21",
                children: "@media (max-width:480px){.btn-sm.jsx-66a2690013a77b21,.badge.jsx-66a2690013a77b21{padding:.25rem .5rem;font-size:.75rem}}"
            }, void 0, false, void 0, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/[locale]/p/[slug]/page.tsx",
        lineNumber: 224,
        columnNumber: 5
    }, this);
}
_s(PublicStoryPage, "Tpx2Am8LF2JfzkBPGLlIpUvxqjA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLocale"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"]
    ];
});
_c = PublicStoryPage;
var _c;
__turbopack_context__.k.register(_c, "PublicStoryPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_7f9435ca._.js.map